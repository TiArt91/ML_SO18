Group S - Alexander Wichmann

Eingabe: Path von Trainingsdatei, Path von Testdatei
Ausgabe: accuracy der Testdatei und des Testteils der Trainingsdatei

run with: java -jar Sheet6.jar Trainingsdatei Testdatei
